#include<stdio.h>

int main(void) {

	printf("%d\n", 10);

	return 0;
}